#	read nerve data
x <- as.numeric(
	unlist(
		strsplit(
			readLines("http://www.stat.cmu.edu/~larry/all-of-nonpar/=data/nerve.dat"), "\\t")
		)
	)
x <- x[!is.na(x)]
n <- length(x)
mu = mean(x)
mu
s2 <- var(x)*(n-1)/n
s2 


library("e1071")
kappa = skewness(x, type = 1)
kappa 
#	jackknife the skewness coefficient
library("e1071")
kappa = skewness(x, type = 1)
jk_kappa <- pseudo_Value <- numeric(n)
for(i in 1:n){
        jk_kappa[i] <- skewness(x[-i], type = 1)
        pseudo_Value[i] <- n * kappa - (n - 1) * jk_kappa[i]
}
kappa_jack <- mean(pseudo_Value)
bias_jack <- (n - 1) * (mean(jk_kappa) - kappa)
se_jack <- sqrt(var(pseudo_Value)/n)
ci_jack <- kappa_jack + c(-1, 1) * qnorm(0.025, lower.tail = F) * se_jack
cat(paste0("jackknife estimate of bias: ", round(bias_jack, 3)),"\n")
cat(paste0("jackknife estimate: ", round(kappa_jack, 3)),"\n")
cat(paste0("jackknife estimate of standard error: ", round(se_jack, 3)),"\n")
cat(paste0("approximate 95% CI: [", round(ci_jack[1], 3), ", ", round(ci_jack[2], 3),"]"),"\n")


#  using bootstrap package
library("bootstrap")
theta <- function(x){skewness(x, type = 1)}
results <- jackknife(x,theta)
# jackknife estimate of standard error       
round(results[[1]], 3)
# jackknife estimate of bias
round(results[[2]], 3)

