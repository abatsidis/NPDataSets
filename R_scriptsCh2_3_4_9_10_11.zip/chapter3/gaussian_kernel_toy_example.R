
Gaussian <- function(u){dnorm(u)}       

w2 <- function(y, h,x){
        n <- length(x)
        apply(
                matrix(rep(y,n),ncol=n),
                1,      
                function(z){sum( dnorm((z-x)/h) )/(n*h)}
                )
}       





x <- c(-7,-5,1,4,5)
pdf(file = '../img/kernel_with_data.pdf', width=9,height=4)
	par(mar=c(4,2,1,1))
	plot(c(-10,10),c(0,0.7),type='n',xlab = 'x',ylab='')
	y <- 1/16
	points(x,rep(y,5),pch=16,col='green',cex=1.5)
	h <- 0.6
	xSeq <- seq(-10,10,length=1000)
	for(i in 1:5){
		points(c(x[i],x[i]),c(0,y),type = 'l',col='green',lwd=1.5)
		points(xSeq, Gaussian((xSeq-x[i])/h)/h,type='l',col='red')
	}
	points(xSeq,w2(xSeq,h,x),type='l',col='blue',lwd=2)
dev.off()

