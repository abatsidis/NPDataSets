n1<-150
df=3
set.seed(20)
x = rt(n=n1, df=df)

library(RColorBrewer)
myCol<-brewer.pal(6, 'Set1')


#	naive kernel (boxcar)
w <- function(y, h,x){
	n <- length(x)
	apply(
		matrix(rep(y,n),ncol=n),
		1, 	
		function(z){sum( dunif((z-x)/h,min=-1,max=1) )/(n*h)}
		)
}	

w(seq(-5,5,by = 2), 0.6, x)



densEvaluations <- 1024
xSeq<-seq(-10,10,length=densEvaluations)
trueDens <- dt(xSeq, df = df)
par(mfrow = c(1, 2))
hist(x,19, freq = F,xlim = c(-10,10), col = 'gray80',border = 'white', main = '', xlab = '')
points(xSeq, trueDens,type='l',col=myCol[1],lwd=3,lty=1)
legend('topright','true',lty=1,col=myCol[1],bty='n')

hist(x,19, freq = F,xlim = c(-10,10), col = 'gray80',border = 'white', main = '', xlab = '')
points(xSeq,w(xSeq,h = 0.6,x),type='l',lwd=2,col=myCol[1])
legend('topright',legend=bquote(hat(f)['n,0.6']),lty=1,col=myCol[1],bty='n')


pdf(file = '../img/t3_true.pdf', width = 9, height = 6)
hist(x,19, freq = F,xlim = c(-10,10), col = 'gray80',border = 'white', main = '', xlab = '')
points(xSeq, trueDens,type='l',col=myCol[1],lwd=3,lty=1)
legend('topright','true',lty=1,col=myCol[1],bty='n')
dev.off()

pdf(file = '../img/t3_naive1.pdf', width = 9, height = 6)
hist(x,19, freq = F,xlim = c(-10,10), col = 'gray80',border = 'white', main = '', xlab = '')
points(xSeq,w(xSeq,h = 0.1,x),type='l',lwd=2,col=myCol[1])
legend('topright',legend=bquote(hat(f)['n,0.1']),lty=1,col=myCol[1],bty='n')
dev.off()

pdf(file = '../img/t3_naive2.pdf', width = 9, height = 6)
hist(x,19, freq = F,xlim = c(-10,10), col = 'gray80',border = 'white', main = '', xlab = '')
points(xSeq,w(xSeq,h = 0.6,x),type='l',lwd=2,col=myCol[1])
legend('topright',legend=bquote(hat(f)['n,0.6']),lty=1,col=myCol[1],bty='n')
dev.off()

pdf(file = '../img/t3_naive3.pdf', width = 9, height = 6)
hist(x,19, freq = F,xlim = c(-10,10), col = 'gray80',border = 'white', main = '', xlab = '')
points(xSeq,w(xSeq,h = 2,x),type='l',lwd=2,col=myCol[1])
legend('topright',legend=bquote(hat(f)['n,2']),lty=1,col=myCol[1],bty='n')
dev.off()


# 	kernel examples

Boxcar <- function(u){dunif(u,min=-1,max=1)}
Gaussian <- function(u){dnorm(u)}	
Epanechnikov <- function(u){0.75*(1-u^2)*(abs(u)<1)}
Tricube <- function(u){70*(1-abs(u)^3)^3*(abs(u)<1)/81}

pdf(file='../img/kernel_examples.pdf',width=9,height=6)
par(mfrow= c(2,2),mar=c(4,4,2,1))
xSeq <- seq(-3,3,length=1000)
plot(xSeq, Boxcar(xSeq), col = 2, lwd = 2, main = 'boxcar', type='l', xlab = 'u', ylab='K(u)')
plot(xSeq, Gaussian(xSeq), col = 2, lwd = 2, main = 'Gaussian', type='l', xlab = 'u', ylab='K(u)')
plot(xSeq, Epanechnikov(xSeq), col = 2, lwd = 2, main = 'Epanechnikov', type='l', xlab = 'u', ylab='K(u)')
plot(xSeq, Tricube(xSeq), col = 2, lwd = 2, main = 'Tricube', type='l', xlab = 'u', ylab='K(u)')
dev.off()


x <- c(-7,-5,1,4,5)
pdf(file = '../img/kernel_with_data.pdf', width=9,height=4)
par(mar=c(4,2,1,1))
plot(c(-10,10),c(0,0.7),type='n',xlab = 'x',ylab='')
y <- 1/16
points(x,rep(y,5),pch=16,col='green',cex=1.5)
h <- 0.6
xSeq <- seq(-10,10,length=1000)
for(i in 1:5){
	points(c(x[i],x[i]),c(0,y),type = 'l',col='green',lwd=1.5)
	points(xSeq, Gaussian((xSeq-x[i])/h)/h,type='l',col='red')
}
points(xSeq,w2(xSeq,h,x),type='l',col='blue',lwd=2)

dev.off()
pdf(file='../img/various_kernels.pdf',width=12,height=6)
par(mfrow=c(2,3),mar=c(2,2,1,1))
plot(density(x, bw='ucv',kernel='gaussian'),col=myCol[1],lwd=1,main='',xlab='',ylab='')
points(density(x, bw='ucv',kernel='epanechnikov'),col=myCol[2],type='l',lwd=1,lty=2)
points(density(x, bw='ucv',kernel='rectangular'),col=myCol[3],type='l',lwd=1,lty=3)
points(density(x, bw='ucv',kernel='triangular'),col=myCol[4],type='l',lwd=1,lty=4)
points(density(x, bw='ucv',kernel='biweight'),col=myCol[5],type='l',lwd=1,lty=5)
plot(density(x, bw='ucv',kernel='gaussian'),col=myCol[1],lwd=2,main='',xlab='',ylab='')
legend('topleft','gaussian',lty=1,col=myCol[1])
plot(density(x, bw='ucv',kernel='epanechnikov'),col=myCol[2],lwd=2,main='',xlab='',ylab='')
legend('topleft','epanechnikov',lty=1,col=myCol[2])
plot(density(x, bw='ucv',kernel='rectangular'),col=myCol[3],lwd=2,main='',xlab='',ylab='')
legend('topleft','boxcar',lty=1,col=myCol[3])
plot(density(x, bw='ucv',kernel='triangular'),col=myCol[4],lwd=2,main='',xlab='',ylab='')
legend('topleft','triangular',lty=1,col=myCol[4])
plot(density(x, bw='ucv',kernel='biweight'),col=myCol[5],lwd=2,main='',xlab='',ylab='')
legend('topleft','biweight',lty=1,col=myCol[5])
dev.off()





