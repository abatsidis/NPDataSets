n <- 30
set.seed(2020)
x = rnorm(n = n)
pdf(file = '../img/normal_hist_example.pdf', width = 17, height = 6)
par(mar = c(4,5,1,1))
hist(x, breaks = seq(-3.5,3.5,by = 0.5), freq=F, xlim = c(-3.5,3.5),col = 'gray80',border = 'white', cex.axis = 1.5, cex.lab = 1.5, 
main = '')
y <- 0.05
for(i in 1:n){
        points(c(x[i],x[i]),c(0,y),type = 'l',col='green',lwd=1.5)
}
points(x,rep(y,n),pch=16,col='green',cex=1.5)
points(x,rep(y,n),pch=1,cex=1.5)
points(seq(-3,3,length = 200), dnorm(seq(-3,3,length = 200)), type = 'l', col = 2, lwd = 2, lty = 2)
points(seq(1.0,1.5,length = 200), dnorm(seq(1.0,1.5,length = 200)), type = 'l', col = 'blue', lwd = 4)
points(c(1,1), c(0,dnorm(1)), type = 'l', col = 'blue', lwd = 4)
points(c(1.5,1.5), c(0,dnorm(1.5)), type = 'l', col = 'blue', lwd = 4)
arrows(1.0, 0.1, x1 = 1.5, y1 = 0.1,code = 3, angle = 10)
text('h = 0.5', x = 1.25, y = 0.12)
h <- 0.5
pj <- length(which((x<1.5)&(x>1)))/(n*h)
pj_true <- (pnorm(1.5) - pnorm(1))/h
points(c(-4,1.5),c(pj,pj),lty = 2, lwd = 1.5,type = 'l')
points(c(-4,1.5),c(pj_true,pj_true),lty = 2, lwd = 1.5,col = 'darkorange',type = 'l')
legend('topleft',lty = 2, lwd = 2, legend='pdf of N(0,1)', col = 'red')
dev.off()



# bin width selection via cross-validation estimation of IMSE

x_low <- -3.5
x_up <- 2.5
m_max <- 15
L <- hValues <- numeric(m_max-1)
j <- 0
for(m in 2:m_max){
        j <- j + 1
        breaks = seq(x_low, x_up, length = m)
        my_hist <- hist(x, breaks = breaks)
        hValues[j] <- h <- (x_up - x_low)/(m-1)
        L[j] <- 2/(h*(n-1)) - (n+1)/(h*(n-1))*sum((h*my_hist$density)^2)
}
pdf(file = '../img/normal_hist_example_risk2.pdf', width = 6, height = 4)
	par(mar = c(4,5,1,1))
	plot(hValues, L, type = 'b', col = 'red', xlab = as.expression(bquote(italic(h))), ylab = as.expression(bquote(hat(italic(J)))))
dev.off()

h <- hValues[which.min(L)]
breaks = seq(x_low, x_up, by = h)
pdf(file = '../img/normal_hist_example_2.pdf', width = 6, height = 4)
hist(x, breaks = breaks, freq = F, col = 'gray80',border = 'white', main = '', xlab = '')
dev.off()

mat1 <- rbind(hValues, L)


# bin width selection via cross-validation estimation of IMSE (illustration of dependence through the origin)

x_low <- -3.65
x_up <- 2.5
m_max <- 15
L <- hValues <- numeric(m_max-1)
j <- 0
for(m in 2:m_max){
        j <- j + 1
        breaks = seq(x_low, x_up, length = m)
        my_hist <- hist(x, breaks = breaks)
        hValues[j] <- h <- (x_up - x_low)/(m-1)
        L[j] <- 2/(h*(n-1)) - (n+1)/(h*(n-1))*sum((h*my_hist$density)^2)
}
pdf(file = '../img/normal_hist_example_risk3.pdf', width = 6, height = 4)
par(mar = c(4,5,1,1))
	plot(hValues,L,type = 'b', col = 'red', xlab = as.expression(bquote(italic(h))), ylab = as.expression(bquote(hat(italic(J)))))
dev.off()

h <- hValues[which.min(L)]
breaks = seq(x_low, x_up, by = h)
pdf(file = '../img/normal_hist_example_3.pdf', width = 6, height = 4)
hist(x, breaks = breaks, freq = F, col = 'gray80',border = 'white', main = '', xlab = '')
dev.off()


mat2 <- rbind(hValues, L)

xtable(cbind(t(mat1), t(mat2)), digits = 3)




