bart <- function(x){
        f <- 0.5*dnorm(x)
        for (j in 0:4){
                f <- f + 0.1*dnorm(x, j/2 - 1, 0.1)
        }
        return(f)
}

xSeq <- seq(-3,3,length=1000)
plot(xSeq, bart(xSeq), col = 'red', lwd=2, xlab='x',ylab='f(x)',type='l')

p <- c(0.5,rep(0.1,5))
mu <- s <- numeric(6)
mu[1] <- 0
s[1] <- 1
for(j in 2:6){
        mu[j] <- (j-2)/2 - 1
        s[j] <- 0.1
}
n <- 1000
set.seed(10)
x <- numeric(n)
for(i in 1:n){
        j <- sample(1:6, 1, prob = p)
        x[i] <- rnorm(1, mu[j], s[j])
}

m_min <- 7 
m_max <- m_min+400
J_cv <- J_plugin <- hValues <- numeric(m_max-m_min)
j <- 0
for(m in m_min:m_max){
        j <- j + 1
        breaks = seq(min(x), max(x), length = m)
        my_hist <- hist(x, breaks = breaks, plot = FALSE)
        hValues[j] <- h <- (max(x) - min(x))/(m-1)
        J_cv[j] <- 2/(h*(n-1)) - (n+1)/(h*(n-1))*sum((h*my_hist$density)^2)
        J_plugin[j] <- -1/h*sum((h*my_hist$density)^2)
}
h <- hValues[which.min(J_cv)]
h
m <- (max(x) - min(x))/h + 1
m


pdf(file='../img/cross_validation_hist.pdf', width=9, height=5)
par(mar=c(4,5,0.2,0.2))
yli <- range(cbind(J_plugin,J_cv))
plot(hValues, J_plugin, ylim = yli, type = 'l', 
	ylab = bquote(hat(italic(J))), 
	xlab = bquote(italic(h)), col = 'blue', lwd = 2)
points(hValues,J_cv,type = 'l',col = 'red', lwd = 2)


points(c(-1, h), c(min(J_cv), min(J_cv)), type = 'l', lty = 2)
points(c(h,h), c(-1, min(J_cv)), type = 'l', lty = 2)
points(h,min(J_cv), pch = 16, col = 1)
legend('bottomright',c('plug-in','cross-validation','selected h'),
	lty=c(1,1,NA), pch = c(NA, NA, 16),col=c('blue','red','black'), lwd = 2)
dev.off()


breaks = seq(min(x), max(x), length = m)

breaks = seq(min(x), max(x), length = m)
hist(x, freq = F, breaks = breaks,col = "gray80", border = "white", 
	main = "", xlab = "", cex.axis = 1.5)


##############################################################################
##############################################################################


#------------------------------------------------------------------------------
#************************KERNEL ESTIMATOR(s)***********************************
#------------------------------------------------------------------------------

library(RColorBrewer)           # high-quality colours
myCol <- brewer.pal(6, 'Set1')

#       estimate density using Gaussian kernel (bandwidth selected via IMSE)
density(x, bw='ucv',kernel='gaussian')
#       estimate density using Epanechnikov kernel (bandwidth selected via IMSE)
density(x, bw='ucv',kernel='epanechnikov')
#       estimate density using boxcar kernel (bandwidth selected via IMSE)
density(x, bw='ucv',kernel='rectangular')
# plot boxcar kernel and compute the estimate of f(x), for a given x  
f_boxcar <- density(x, bw='ucv',kernel='rectangular')
plot(f_boxcar)
f_boxcar$x[260] # x approx 0.69
f_boxcar$y[260] # density estimate f(0.69) = 0.27

#       plot estimated densities all together and one-by-one

pdf(file ='../img/bart_various_kernels.pdf', width = 10, height = 5)
par(mfrow=c(2,3),mar=c(2,2,1,1))
plot(density(x, bw='ucv',kernel='gaussian'),col=myCol[1],lwd=2,main='',xlab='',ylab='')
points(density(x, bw='ucv',kernel='epanechnikov'),col=myCol[2],type='l',lwd=2,lty=2)
points(density(x, bw='ucv',kernel='rectangular'),col=myCol[3],type='l',lwd=2,lty=3)
points(density(x, bw='ucv',kernel='triangular'),col=myCol[4],type='l',lwd=2,lty=4)
points(density(x, bw='ucv',kernel='biweight'),col=myCol[5],type='l',lwd=2,lty=5)
legend('topright', c('gaussian', 'epanechnikov', 'boxcar', 'triangular', 'biweight'), col =myCol[1:5], lty=1:5, lwd=2)
plot(density(x, bw='ucv',kernel='gaussian'),col=myCol[1],lwd=2,main='',xlab='',ylab='')
legend('topright','gaussian',lty=1,col=myCol[1])
plot(density(x, bw='ucv',kernel='epanechnikov'),col=myCol[2],lwd=2,main='',xlab='',ylab='')
legend('topright','epanechnikov',lty=1,col=myCol[2])
plot(density(x, bw='ucv',kernel='rectangular'),col=myCol[3],lwd=2,main='',xlab='',ylab='')
legend('topright','boxcar',lty=1,col=myCol[3])
plot(density(x, bw='ucv',kernel='triangular'),col=myCol[4],lwd=2,main='',xlab='',ylab='')
legend('topright','triangular',lty=1,col=myCol[4])
plot(density(x, bw='ucv',kernel='biweight'),col=myCol[5],lwd=2,main='',xlab='',ylab='')
legend('topright','biweight',lty=1,col=myCol[5])
dev.off()





