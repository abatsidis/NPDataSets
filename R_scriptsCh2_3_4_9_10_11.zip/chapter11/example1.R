#########################################################
#	Bootstrap estimators of normal distribution	#
#########################################################
set.seed(99999)
n <- 20
mu.true <- 20
s2.true <- 4
x <- rnorm(n, mu.true, sqrt(s2.true))
x <- round(x, 2)


x <- c(19.15, 19.43, 18.2, 21.41, 24.18, 23.27, 18.92, 18.79, 19.59, 
19.38, 21.91, 19.22, 19.71, 19.26, 21.22, 16.67, 17.56, 22.55, 20.47, 21.87)

set.seed(1)
theta_hat1 <- mean(x)
theta_hat2 <- (n-1)*var(x)/n
B = 1000
n <- length(x)
theta_values1 <- numeric(B)
theta_values2 <- numeric(B)
for (i in 1:B){
	y <- x[sample(n, n, replace = TRUE)]
	theta_values1[i] <- mean(y)
	theta_values2[i] <- (n-1)*var(y)/n
}

theta_star1 <- mean(theta_values1)
standard_error1 <- sqrt(sum((theta_values1 - theta_star1)^2)/(B-1))
theta_star2 <- mean(theta_values2)
standard_error2 <- sqrt(sum((theta_values2 - theta_star2)^2)/(B-1))

standard_error1
standard_error2

sqrt(var(x)/n)
Gshape = (n - 1)/2
Grate = n/(2*theta_hat2)
sqrt(Gshape/(Grate^2))

#bootstrap bias estimates
theta_star1 - theta_hat1
theta_star2 - theta_hat2

#	add estimated sampling distribution of sample mean and sample var
#	
pdf(file='../img/ex11_1a.pdf',width=6,height=5)
	par(mar = c(4,4,1,1))
	xSeq1 <- seq(18, 22, length = 1000)
	hist(theta_values1,  freq=F, xlab = bquote(bar(italic(X))),main='', col= 'white')
	points(xSeq1, dnorm(xSeq1, theta_hat1, sqrt(theta_hat2/n)), type = 'l', lwd = 2, col = 'blue')
dev.off()
pdf(file='../img/ex11_1b.pdf',width=6,height=5)
	par(mar = c(4,4,1,1))
	xSeq2 <- seq(0, 10, length = 1000)
	hist(theta_values2,  freq=F, xlab = bquote(hat(italic(sigma))^2),main='', col= 'white')
	points(xSeq2, dgamma(xSeq2, shape = (n - 1)/2, rate = n/(2*theta_hat2)), type = 'l', lwd = 2, col = 'blue')
dev.off()


# add jack-knife result for standard error
jk_mean <- pseudo_ValueMean <- numeric(n)
jk_var <- pseudo_ValueVar <- numeric(n)
for(i in 1:n){
        jk_mean[i] <- mean(x[-i])
        jk_var[i] <- (n-2)*var(x[-i])/(n-1)
        pseudo_ValueMean[i] <- n*theta_hat1 - (n-1)*jk_mean[i]
        pseudo_ValueVar[i] <- n*theta_hat2 - (n-1)*jk_var[i]
}
se_jackMean <- sqrt(var(pseudo_ValueMean)/n)
se_jackVar <- sqrt(var(pseudo_ValueVar)/n)
# jackknife bias estimates
(n-1)*(mean(jk_mean)- theta_hat1)
(n-1)*(mean(jk_var)- theta_hat2)


#
# 95% normal CI (asymptotic) with bias correction (2.4 page 14, in Davison and Hinkley)
#
NormalCIMean <- 2*theta_hat1 - theta_star1 + c(-1,1)*qnorm(0.025,lower.tail=FALSE)*standard_error1
NormalCIVar <- 2*theta_hat2 - theta_star2 + c(-1,1)*qnorm(0.025,lower.tail=FALSE)*standard_error2
#
# 95% percentile bootstrap interval
#
PercentileCIMean <- quantile(theta_values1,probs = c(0.025, 0.975), type = 1)
PercentileCIVar <- quantile(theta_values2,probs = c(0.025, 0.975), type = 1)
#
# 95% basic bootstrap interval (or reverse percentile interval)
#
BasicCIMean <- 2*theta_hat1-c(quantile(theta_values1,probs = c(0.975, 0.025), type = 1))
BasicCIVar <- 2*theta_hat2-c(quantile(theta_values2,probs = c(0.975, 0.025), type = 1))


# jack-knife for mean and variance
jk_Mean <- jk_Var <- pseudo_Mean <- pseudo_Var <- numeric(n)
mu <- mean(x)
s2 <- (n-1)/n*var(x)
for(i in 1:n){
        jk_Mean[i] <- mean(x[-i])
        jk_Var[i] <- (n-2)/(n-1)*var(x[-i])
        pseudo_Mean[i] <- n*mu - (n-1)*jk_Mean[i]
        pseudo_Var[i] <- n*s2 - (n-1)*jk_Var[i]
}
theta_jack1 <- mean(pseudo_Mean)
se_jack1 <- sqrt(var(pseudo_Mean)/n)
jackCIMean <- theta_jack1 + c(-1, 1)*qnorm(0.025,lower.tail=F)*se_jack1
theta_jack2 <- mean(pseudo_Var)
se_jack2 <- sqrt(var(pseudo_Var)/n)
jackCIVar <- theta_jack2 + c(-1, 1)*qnorm(0.025,lower.tail=F)*se_jack2

# exact CI
exactMean <- mean(x)+c(-1,1)*qt(0.025,df = n - 1, lower.tail=FALSE)*sqrt(var(x)/n)
exactVar <- (n-1)*var(x)/qchisq(c(0.975, 0.025), df = n - 1)


# studentized with bootstrap inside bootstrap
set.seed(1)
B2 <- 50
theta_hat1 <- mean(x)
theta_hat2 <- (n-1)*var(x)/n
ksi1 <- theta_values1 <- numeric(B)
ksi2 <- theta_values2 <- numeric(B)
t1 <- t2 <- numeric(B2)
for (i in 1:B){
	y <- x[sample(n, n, replace = TRUE)]
	theta_values1[i] <- mean(y)
	theta_values2[i] <- (n-1)*var(y)/n
	for(j in 1:B2){
		bootstar <- sample(y, replace=T)
		t1[j] <- mean(bootstar)
		t2[j] <- (n-1)*var(bootstar)/n
	}
	ksi1[i]<- (theta_values1[i] - theta_hat1)/sqrt(var(t1))
	ksi2[i]<- (theta_values2[i] - theta_hat2)/sqrt(var(t2))
}
theta_star1 <- mean(theta_values1)
theta_star2 <- mean(theta_values2)
standard_error1 <- sqrt(sum((theta_values1 - theta_star1)^2)/(B-1))
standard_error2 <- sqrt(sum((theta_values2 - theta_star2)^2)/(B-1))
studentizedCIMeanB <- theta_hat1 + quantile(ksi1,probs=c(0.025, 0.975)) * standard_error1 #sqrt(var(theta_values1)) 
studentizedCIVarB <- theta_hat2 + quantile(ksi2,probs=c(0.025, 0.975))* standard_error2  #sqrt(var(theta_values2)) 
studentizedCIMeanB
studentizedCIVarB


studentizedCIMeanBC <- 2*theta_hat1 - theta_star1 + quantile(ksi1,probs=c(0.025, 0.975)) * standard_error1 #sqrt(var(theta_values1)) 
studentizedCIVarBC <- 2*theta_hat2 - theta_star2 + quantile(ksi2,probs=c(0.025, 0.975))* standard_error2  #sqrt(var(theta_values2)) 
studentizedCIMeanBC
studentizedCIVarBC


#	using the boot package
#	1.	Define a function that returns the statistic we want
get_theta <- function(data, indices){
	y <- data[indices]
	theta <- c(mean(y), (n-1)*var(y)/n)
	return(theta)
}
#	2.	Use the boot function to get R bootstrap replicates of the statistic
set.seed(12345)
boot_out <- boot(x, R = 1000, statistic = get_theta)
#	3.	Use the boot.ci function to get the confidence intervals
boot.ci(boot_out)




#	using the boot package
#	1.	Define a function that returns the statistic we want
get_theta <- function(data, indices){
	y <- data[indices]
	theta <- (n-1)*var(y)/n
	return(theta)
}
#	2.	Use the boot function to get R bootstrap replicates of the statistic
set.seed(12345)
boot_out <- boot(x, R = 1000, statistic = get_theta)
#	3.	Use the boot.ci function to get the confidence intervals
boot.ci(boot_out)




myTable <- cbind( rbind(
	exactMean,
	jackCIMean,
	NormalCIMean,
	BasicCIMean,
	PercentileCIMean, 
	studentizedCIMeanB, 
	boot.ci(boot_out, index = 1)$bca[,4:5]),
		rbind(
			exactVar, 
			jackCIVar,
			NormalCIVar,
			BasicCIVar,
			PercentileCIVar,
			studentizedCIVarB,
			boot.ci(boot_out, index = 2)$bca[,4:5])
)
colnames(myTable) <- c('mu_l', 'mu_u', 's2_l', 's2_u')
rownames(myTable) <- c('Exact CI', 'Normal Jackknife', 'Normal bootstrap CI', 'Basic bootstrap CI', 'Percentile bootstrap CI', 'Studentized', 'BCa')




#########################################################
#	Bootstrap for correlation coefficient		#
#		(school dataset, Efron 1979)		#
#########################################################
x <- data.frame(
	LSAT = c(576, 635, 558, 578, 666, 580, 555, 661, 651, 605, 653, 575, 545, 572, 594),
	GPA = c(3.39, 3.30, 2.81, 3.03, 3.44, 3.07, 3.00, 3.43, 3.36, 3.13, 3.12, 2.74, 2.76, 2.88, 2.96)
)
#	using the boot package
#	1.	Define a function that returns the statistic we want
get_r <- function(data, indices){
	y <- data[indices, ]
	return(cor(y)[1,2])
}
#	2.	Use the boot function to get R bootstrap replicates of the statistic
set.seed(12345)
boot_out <- boot(x, R = 10000, statistic = get_r)
#	3.	Use the boot.ci function to get the confidence intervals
boot.ci(boot_out)

theta_hat <- cor(x)[1,2]
plot(x, pch = 16, cex = 2, main = paste0('cor(LSAT, GPA) = ',round(theta_hat,3)))
B = 10000
n <- dim(x)[1]
theta_values <- numeric(B)
for (i in 1:B){
	y <- x[sample(n, n, replace = TRUE), ]
	theta_values[i] <- cor(y)[1,2]
}
hist(theta_values - theta_hat)
theta_star <- mean(theta_values)
standard_error <- sqrt(sum((theta_values-theta_star)^2)/(B-1))
standard_error

#
# 95% normal CI (asymptotic) with bias correction (2.4 page 14, in Davison and Hinkley)
#
2*theta_hat - theta_star + c(-1,1)*1.96*standard_error
#
# 95% percentile bootstrap interval
#
quantile(theta_values,probs = c(0.025, 0.975))
#
# 95% basic bootstrap interval (or reverse percentile interval)
#
2*theta_hat-c(quantile(theta_values,probs = c(0.975, 0.025)))
theta_hat - quantile(theta_values-theta_hat,  probs = c(0.975,0.025))
#
# Bca bias-corrected CIs
#
Z = qnorm( length(theta_values[theta_values<=theta_hat])/B )
# estimation of acceleration factor using jackknife approach
alpha<-0.05
jk_values <- numeric(n)
for( i in 1:n ){
	jk_values[i] <- cor(x[-i, ])[1,2]
}
jk_mean <- mean(jk_values)
A <- sum((jk_values - jk_mean)^3) / (6*(sum((jk_values-jk_mean)^2))^1.5)
A1 <- pnorm(Z + (Z-qnorm(alpha/2,lower.tail=F))/(1-A*(Z-qnorm(alpha/2,lower.tail=F))) )
A2 <- pnorm(Z + (Z+qnorm(alpha/2,lower.tail=F))/(1-A*(Z+qnorm(alpha/2,lower.tail=F))) )
quantile(theta_values, probs = c(A1,A2))
#
# algorithm for studentized interval
#
	B2 <- 2000
	B = 2000
	n <- dim(x)[1]
	theta_values <- numeric(B)
	xi_values <- numeric(B)
	theta_values2 <- numeric(B2)
	for (i in 1:B){
		y <- x[sample(n, n, replace = TRUE), ]
		theta_values[i] <- cor(y)[1,2]	
		for(j in 1:B2){
			z <- y[sample(n, n, replace = TRUE), ]
			theta_values2[j] <- cor(z)[1,2]	
		}
		standard_error_iteration <- sqrt(var(theta_values2))
		xi_values[i] <- (theta_values[i] - theta_hat)/standard_error_iteration
		cat(paste0('   i = ',i),'\r')
	}
	theta_hat + quantile(xi_values,probs=c(0.025, 0.975))*sqrt(var(theta_values)) 


# jack-knife
jk_values<-numeric(n)
for(i in 1:n){
	jk_values[i] <- cor(x[-i,])[1,2]
}
jk_se <- sqrt(((n-1)*sum((jk_values - mean(jk_values))^2))/n)

	B = 10000
	n <- dim(x)[1]
	theta_values <- numeric(B)
	xi_values <- numeric(B)
	jk_values <- numeric(n)
	for (i in 1:B){
		y <- x[sample(n, n, replace = TRUE), ]
		theta_values[i] <- cor(y)[1,2]	
		for(j in 1:n){
			jk_values[j] <- cor(y[-j,])[1,2]
		}
		standard_error_iteration <- sqrt(((n-1)*sum((jk_values - mean(jk_values))^2))/n)
		xi_values[i] <- (theta_values[i] - theta_hat)/standard_error_iteration
		cat(paste0('   i = ',i),'\r')
	}
	theta_hat + quantile(xi_values,probs=c(0.025, 0.975))*sqrt(var(theta_values)) 

	B = 10000
	n <- dim(x)[1]
	theta_values <- numeric(B)
	xi_values <- numeric(B)
	jk_values <- numeric(n)
	for (i in 1:B){
		y <- x[sample(n, n, replace = TRUE), ]
		theta_values[i] <- cor(y)[1,2]	
		for(j in 1:n){
			jk_values[j] <- cor(y[-j,])[1,2]
		}
		standard_error_iteration <- sqrt(((n-1)*sum((jk_values - mean(jk_values))^2))/n)
		xi_values[i] <- (theta_values[i] - theta_hat)/standard_error_iteration
		cat(paste0('   i = ',i),'\r')
	}
	theta_hat + quantile(xi_values,probs=c(0.025, 0.975))*sqrt(var(theta_values)) 






#########################################################
#	Bootstrap for regression problem		#
#		(survival dataset, Efron)		#
#########################################################
library(boot)
data(survival)
pdf('../img/survivalScatter.pdf', width = 6, height = 6)
plot(survival$dose, log(survival$surv), pch = 16, cex = 1.5)
dev.off()

pdf('../img/survivalQQ.pdf', width = 6, height = 6)
qqnorm(rstandard(fit), pch = 16, cex = 1.5)
qqline(rstandard(fit), lwd = 1.5, col = 2)
dev.off()



#########################################################
#	Bootstrap for regression problem		#
#		(survival dataset, Efron)		#
#########################################################
library(boot)
data(survival)
plot(survival$dose, log(survival$surv), pch = 16, cex = 1.5)
fit <- lm(log(survival$surv) ~ survival$dose)
plot(fit)

e <- fit$residuals
a <- fit$coefficients[1]
b <- fit$coefficients[2]


#-------------------------------------------------
#	using the boot package (bootstrap residuals)
#-------------------------------------------------
library(boot)
data(survival)
fit <- lm(log(survival$surv) ~ survival$dose)
e <- fit$residuals
a <- fit$coefficients[1]
b <- fit$coefficients[2]
surv.fun <- function(data, indices){
	d <- data[indices]
	y_boot <- a + b*survival$dose + d
	d.reg <- lm(y_boot ~ survival$dose)
	c(coef(d.reg))
}
set.seed(1)
surv.boot <- boot(e,surv.fun,R=1000)
boot.ci(surv.boot, index = 2)

pdf(file = '../tex/image/reg_res_boot.pdf', width=9,height=6)
par(mar=c(5,5,2,2))
plot(surv.boot$t,col=2,pch=16,xlab=bquote(hat(alpha)),ylab=bquote(hat(beta)),cex.axis=1.5,cex.lab=1.5)
dev.off()


library(ggplot2)
df <- as.data.frame(surv.boot$t) 
p <- ggplot(df, aes(V1, V2)) + geom_point() + theme_classic() + ylab(bquote(hat(beta))) + xlab(bquote(hat(alpha)))
pdf('../img/reg_res_boot.pdf', width=9,height=6)
ggExtra::ggMarginal(p, type = "histogram", col = "blue", fill = "orange")
dev.off()

# (bootstrap (x, y))


surv.fun <- function(data, indices){
	d <- data[indices, ]
	d.reg <- lm(log(d$surv) ~ d$dose)
	c(coef(d.reg))
}
surv.boot <- boot(survival,surv.fun,R=1000)
boot.ci(surv.boot, index = 2)

pdf(file='survival_boot.pdf',width=12,height=4)
plot(surv.boot,index=2)
dev.off()
pdf(file='../tex/image/survival_boot_coef.pdf',width=12,height=6)
	par(mar=c(5,5,1,1))
	plot(surv.boot$t,col=2,pch=16,xlab=bquote(hat(alpha)),ylab=bquote(hat(beta)),cex.axis=1.5,cex.lab=1.5)
dev.off()

theta_hat <- as.numeric(coef(lm(log(surv)~dose,data=survival))[2])
B = 10000
n <- dim(survival)[1]
theta_values <- numeric(B)
for (i in 1:B){
	y <- survival[sample(n, n, replace = TRUE), ]
	theta_values[i] <- as.numeric(coef(lm(log(surv)~dose,data=y))[2])
}
hist(theta_values - theta_hat)
theta_star <- mean(theta_values)
standard_error <- sqrt(sum((theta_values-theta_star)^2)/(B-1))
standard_error

#plot few bootstrap regression lines
pdf(file = 'survival3.pdf',width=9,height=6)
set.seed(4232325)
B = 40
n <- dim(survival)[1]
plot(survival$dose, log(survival$surv), pch = 16, cex = 1.5,col='blue')
abline(lm(log(survival$surv)~survival$dose),col='blue',lwd=2)
for (i in 1:B){
	y <- survival[sample(n, n, replace = TRUE), ]
	abline(lm(log(surv)~dose,data=y),col='gray70',lwd=1)
}
points(survival$dose, log(survival$surv), pch = 16, cex = 1.5,col='blue')
abline(lm(log(survival$surv)~survival$dose),col='red',lwd=2)
legend('bottomleft',c('regression line','bootstrap samples'),col=c('red','gray70'),lty=1,lwd=2)
dev.off()

pdf(file = 'survival2.pdf',width=9,height=6)
plot(survival$dose, log(survival$surv), pch = 16, cex = 1.5,col='blue')
abline(lm(log(survival$surv)~survival$dose),col='red',lwd=2)
dev.off()

pdf(file = 'survival1.pdf',width=9,height=6)
plot(survival$dose, log(survival$surv), pch = 16, cex = 1.5,col='blue')
dev.off()

#
# 95% normal CI (asymptotic)
#
2*theta_hat - theta_star + c(-1,1)*qnorm(0.025,lower.tail=F)*standard_error
#
# 95% percentile bootstrap interval
#
quantile(theta_values,probs = c(0.025, 0.975))
#
# 95% basic bootstrap interval (or reverse percentile interval)
#
2*theta_hat-c(quantile(theta_values,probs = c(0.975, 0.025)))
theta_hat - quantile(theta_values-theta_hat,  probs = c(0.975,0.025))
#
# Bca bias-corrected CIs
#
Z = qnorm( length(theta_values[theta_values<=theta_hat])/B )
# estimation of acceleration factor using jackknife approach
alpha<-0.05
jk_values <- numeric(n)
for( i in 1:n ){
	y <- survival[-i, ]
	jk_values[i] <-  as.numeric(coef(lm(log(surv)~dose,data = y))[2])
}
jk_mean <- mean(jk_values)
A <- sum((jk_values - jk_mean)^3) / (6*(sum((jk_values-jk_mean)^2))^1.5)
A1 <- pnorm(Z + (Z-qnorm(alpha/2,lower.tail=F))/(1-A*(Z-qnorm(alpha/2,lower.tail=F))) )
A2 <- pnorm(Z + (Z+qnorm(alpha/2,lower.tail=F))/(1-A*(Z+qnorm(alpha/2,lower.tail=F))) )
quantile(theta_values, probs = c(A1,A2))
#
# algorithm for studentized interval
#
	B2 <- 200
	B = 1000
	n <- dim(x)[1]
	theta_values <- numeric(B)
	xi_values <- numeric(B)
	theta_values2 <- numeric(B2)
	for (i in 1:B){
		y <- survival[sample(n, n, replace = TRUE), ]
		theta_values[i] <- as.numeric(coef(lm(log(surv)~dose,data=y))[2])
		for(j in 1:B2){
			z <- y[sample(n, n, replace = TRUE), ]
			theta_values2[j] <- as.numeric(coef(lm(log(surv)~dose,data = z))[2])	
		}
		standard_error_iteration <- sqrt(var(theta_values2))
		xi_values[i] <- (theta_values[i] - theta_hat)/standard_error_iteration
		cat(paste0('   i = ',i),'\r')
	}
	theta_hat + quantile(xi_values,probs=c(0.025, 0.975), na.rm=TRUE)*sqrt(var(theta_values)) 


#########################################################
#	Bootstrap for median				#
#		(simulated data)			#
#########################################################
set.seed(1)
#x <- rgamma(n=15, shape = 1, rate = 0.5)
x <- rexp(n = 30,  rate = log(2))
get_median <- function(data, indices){
	y <- data[indices]
	return(median(y))
}
#	2.	Use the boot function to get R bootstrap replicates of the statistic
set.seed(12345)
boot_out <- boot(x, R = 10000, statistic = get_median)
#	3.	Use the boot.ci function to get the confidence intervals
boot.ci(boot_out)




theta_hat <- median(x)
B = 10000
n <- length(x)
theta_values <- numeric(B)
for (i in 1:B){
	y <- x[sample(n, n, replace = TRUE)]
	theta_values[i] <- median(y)
}
hist(theta_values - theta_hat)
theta_star <- mean(theta_values)
standard_error <- sqrt(sum((theta_values-theta_star)^2)/(B-1))
standard_error

#
# 95% normal CI (asymptotic)
#
2*theta_hat - theta_star + c(-1,1)*1.96*standard_error
#
# 95% percentile bootstrap interval
#
quantile(theta_values,probs = c(0.025, 0.975))
#
# 95% basic bootstrap interval (or reverse percentile interval)
#
2*theta_hat-c(quantile(theta_values,probs = c(0.975, 0.025)))
theta_hat - quantile(theta_values-theta_hat,  probs = c(0.975,0.025))
#
# Bca bias-corrected CIs
#
Z = qnorm( length(theta_values[theta_values<=theta_hat])/B )
# estimation of acceleration factor using jackknife approach
alpha<-0.05
jk_values <- numeric(n)
for( i in 1:n ){
	jk_values[i] <- median(x[-i])
}
jk_mean <- mean(jk_values)
A <- sum((jk_values - jk_mean)^3) / (6*(sum((jk_values-jk_mean)^2))^1.5)
A1 <- pnorm(Z + (Z-qnorm(alpha/2,lower.tail=F))/(1-A*(Z-qnorm(alpha/2,lower.tail=F))) )
A2 <- pnorm(Z + (Z+qnorm(alpha/2,lower.tail=F))/(1-A*(Z+qnorm(alpha/2,lower.tail=F))) )
quantile(theta_values, probs = c(A1,A2))
#
# algorithm for studentized interval
#
	B2 <- 2000
	B = 2000
	n <- length(x)
	theta_values <- numeric(B)
	xi_values <- numeric(B)
	theta_values2 <- numeric(B2)
	for (i in 1:B){
		y <- x[sample(n, n, replace = TRUE) ]
		theta_values[i] <- median(y)
		for(j in 1:B2){
			z <- y[sample(n, n, replace = TRUE)]
			theta_values2[j] <- median(z)
		}
		standard_error_iteration <- sqrt(var(theta_values2))
		xi_values[i] <- (theta_values[i] - theta_hat)/standard_error_iteration
		cat(paste0('   i = ',i),'\r')
	}
	theta_hat + quantile(xi_values,probs=c(0.025, 0.975))*sqrt(var(theta_values)) 
#	2nd example for median

set.seed(1)
sh<-2; ra<-1
x <- rt(n=1000, df=sh)
get_median <- function(data, indices){
	y <- data[indices]
	return(median(y))
}

theta_hat <- median(x)
B = 10000
n <- length(x)
theta_values <- numeric(B)
for (i in 1:B){
	y <- x[sample(n, n, replace = TRUE)]
	theta_values[i] <- median(y)
}
hist(theta_values,freq=F)
abline(v=qt(0.5, df=sh),col='blue',lwd=2)
points(density(theta_values),type='l',col='red',lwd=2)
abline(v=median(x),col='red',lwd=2)
abline(v=mean(theta_values),col='red',lwd=2,lty=2)
#########################################################
#	Bootstrap for max				#
#		(simulated data)			#
#########################################################
n <- 50
x <- runif(n)
xmax<-max(x)
#distribution of max:
f_max <- function(w,n,theta){(n*w^{n-1})/(theta^n)}
xSeq <- seq(0.8,1,length=100)
plot(xSeq, f_max(xSeq,n=n,theta=1), type = 'l', lwd=1.5)
# parametric bootstrap
B <- 10000
theta_max_pm <- numeric(B)
for(i in 1:B){
	xsim <- xmax*runif(n)
	theta_max_pm[i] <- max(xsim)
}
#nonparametrit bootstrap
theta_hat <- xmax
theta_values <- numeric(B)
for (i in 1:B){
	y <- x[sample(n, n, replace = TRUE) ]
	theta_values[i] <- max(y)
}

par(mfrow = c(1,2))
xSeq <- seq(0,1,length = 1000)
hist(theta_max_pm, freq= FALSE)
points(xSeq, f_max(xSeq,n=n,theta=1), type = 'l', lwd=1.5)
hist(theta_values, freq= FALSE)
points(xSeq, f_max(xSeq,n=n,theta=1), type = 'l', lwd=1.5)


#########################################################
#	Bootstrap for contingency table			#
#########################################################

# define data frame
dataFrame <- data.frame(
                trauma = factor(c(0,0,1,1),levels=c(0,1), labels=c('yes','no')),
                depression = factor(c(0,1,0,1),levels=c(0,1),labels=c('yes','no')),
                freq = c(33,131,4,251)
                )
# create contigency table
dataTable <- xtabs(freq~trauma+depression,data=dataFrame)
n <- sum(dataTable)
rSum <- rowSums(dataTable)      #marginal frequencies (trauma)
cSum <- colSums(dataTable)      #marginal frequencies (depression)
est.prob <- dataFrame$freq/n
theta_hat <- as.numeric(
                dataTable[1,1]/rSum[1] - dataTable[2,1]/rSum[2]
                )
se <- as.numeric(
                sqrt(
                        (cSum[1]/n)*(1 - cSum[1]/n)*sum(1/rSum) 
                )
        )
#      Asymptotic CI 
z = theta_hat/se
normQuantile <- qnorm(p=0.025, mean=0,sd=1, lower.tail=FALSE)
ciDIFF <- hat + c(-1,1)*normQuantile*se

B = 10000
theta_values <- numeric(B)
for (i in 1:B){
	bootFreq <- rmultinom(n = 1, size = n, prob = est.prob)
	bootFrame <- data.frame(
		        trauma = factor(c(0,0,1,1),levels=c(0,1), labels=c('yes','no')),
		        depression = factor(c(0,1,0,1),levels=c(0,1),labels=c('yes','no')),
		        freq = bootFreq
		        )
	bootTable <- xtabs(freq~trauma+depression,data=bootFrame)
	brSum <- rowSums(bootTable)      #marginal frequencies (trauma)
	bcSum <- colSums(bootTable)      #marginal frequencies (depression)
	bootEstimate <- as.numeric(
		        bootTable[1,1]/brSum[1] - bootTable[2,1]/brSum[2]
		        )
	theta_values[i] <- bootEstimate
}
hist(theta_values - theta_hat)
theta_star <- mean(theta_values)
standard_error <- sqrt(sum((theta_values-theta_star)^2)/(B-1))
standard_error

#
# 95% normal CI (asymptotic) with bias correction (2.4 page 14, in Davison and Hinkley)
#
2*theta_hat - theta_star + c(-1,1)*1.96*standard_error
#
# 95% percentile bootstrap interval
#
quantile(theta_values,probs = c(0.025, 0.975))
#
# 95% basic bootstrap interval (or reverse percentile interval)
#
2*theta_hat-c(quantile(theta_values,probs = c(0.975, 0.025)))



#########################################################
#	Bootstrap for testing mean			#
#########################################################

x <- c(-0.89,-0.47,0.05,0.155,0.279,0.775,1.0016,1.23,1.89,1.96)
x_tilde <- x + 1 - mean(x)
n <- length(x)
t0 <- abs(mean(x) - 1)
B <- 1000
theta_values <- numeric(B)
set.seed(1)
for (b in 1:B){
	bootsample <- sample(x_tilde,replace=TRUE)
	theta_values[b] <- abs(mean(bootsample) - 1) 
}
pvalue_boot <- sum(theta_values > t0)/B
pvalue_boot


pdf(file='../img/hist_abs_statistic.pdf',width=12,height=6)
	par(mar=c(2,4,1,1))
	hist(theta_values,main='',xlab='',cex.axis=2)
	abline(v=t0,col='red',lwd=4,lty=2)
dev.off()




pvalue_boot <- sum(theta_values > t0)/B


##### pivotal test-statistic

for (b in 1:B){
	bootsample <- sample(x_tilde,replace=TRUE)
	theta_values[b] <- sqrt(n) * abs(mean(bootsample) - 1) / sqrt(var(bootsample))
}
t0 <- sqrt(n)*abs(mean(x) - 1)/sqrt(var(x))
pvalue_boot <- sum(theta_values > t0)/B
pvalue_boot


#########################################################
#	Bootstrap for testing equality of means		#
#		(Mouse data)				#
# http://galton.uchicago.edu/~eichler/stat24600/Handouts/bootstrap.pdf
#########################################################
x <- c( 94,  197,   16,   38,  99,  141,  23)
y <- c(52,  104,  146,  10,  51,   30,   40,  27,  46)
x_tilde <- x - mean(x) + mean(c(x,y))
y_tilde <- y - mean(y) + mean(c(x,y))
t0 <-  t.test(x,y,alternative='greater',paired=F,var.equal=F)$statistic
B <- 1000
theta_values <- numeric(B)
n1 <- length(x)
n2 <- length(y)
set.seed(1)
for (i in 1:B){
	x_b <- x_tilde[sample(n1, n1, replace = TRUE)]
	y_b <- y_tilde[sample(n2, n2, replace = TRUE)]
	theta_values[i] <- t.test(x_b,y_b,alternative='greater',paired=F,var.equal=F)$statistic
}
pvalue_boot <- length(theta_values[theta_values>t0])/B
pvalue_boot

pdf(file='../img/hist_welch_statistic.pdf',width=12,height=6)
	par(mar=c(2,4,1,1))
	hist(theta_values,main='',xlab='',cex.axis=2)
	abline(v=t0,col='red',lwd=4,lty=2)
dev.off()

wilcox.test(x,y,alternative='greater', paired=F)



