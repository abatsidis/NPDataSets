cmb_data <- read.table('wmap.dat',header=TRUE)



y <- cmb_data[1:400,2]
x <- cmb_data[1:400,1]
n <- length(x)

pdf(file ='../img/cmb_data.pdf',width=9,height=6)
	plot(x,y,col='gray40',xlab='frequency',ylab='power')
dev.off()



#---------------------------------------------------------
# regressogram
#---------------------------------------------------------


regressogram <- function(h,plot=F){
	b <- max(x)
	a <- min(x)
	nBreaks <- (b-a)/h
	binnedX <- cut(x,breaks=nBreaks)
	# split y according to binnedX
	splitY <- split(y,binnedX)
	splitIndex<-split(1:n,binnedX)
	# smoothing matrix
	L <- matrix(data=0, nrow = n, ncol = n)
	for(j in 1:length(splitIndex)){
		L[splitIndex[[j]],splitIndex[[j]]] <- 1/length(splitIndex[[j]])
	}
	rg <- L%*%matrix(y)
	if(plot==TRUE){
		plot(x,y,col='gray40')
		points(x,rg,type='l',col='red',lwd=2)
		legend('topright',paste0('m = ',floor((b-a)/h), ' (h = ', round(h, 1),')'))
	}
	return(rg)
}

cvScore <- function(h){
	b <- max(x)
	a <- min(x)
	nBreaks <- (b-a)/h
	binnedX <- cut(x,breaks=nBreaks)
	# split y according to binnedX
	splitY <- split(y,binnedX)
	splitIndex<-split(1:n,binnedX)
	# smoothing matrix
	L <- matrix(data=0, nrow = n, ncol = n)
	for(j in 1:length(splitIndex)){
		L[splitIndex[[j]],splitIndex[[j]]] <- 1/length(splitIndex[[j]])
	}
	rg <- L%*%matrix(y)
	return(
		mean(
			( (y-rg)/(1-diag(L)) )^2
		)
	)
}

h <- seq(1,30,length=100)
cvValues <- numeric(100)
j<-0
for(i in h){
	j<-j+1
	cvValues[j] <- cvScore(i)
}
pdf(file = '../img/loocvRG.pdf', width = 9, height = 6)
plot(h,cvValues, ylab = 'Leave-one-out cross-validation score',xlab='smoothing parameter (h)',type = 'l',col='darkorange', lwd = 2)
dev.off()

hCV <- h[which.min(cvValues)]



reg <- regressogram(hCV,plot=T)
pdf(file = 'regressograms_cmb.pdf',width=9,height=6)
	par(mfrow = c(2,2),mar=c(4,4,1,1))
	regressogram(hCV-12,plot=T)
	regressogram(hCV-8,plot=T)
	regressogram(hCV,plot=T)
	regressogram(hCV+70,plot=T)
dev.off()

pdf(file = '../img/regressogram_cmb.pdf',width=9,height=6)
par(mfrow = c(2,2),mar=c(4,4,1,1))
regressogram(6,  plot = T)
regressogram(10, plot = T)
regressogram(18, plot = T)
regressogram(88, plot = T)
dev.off()

#---------------------------------------------------------
# Nadaraya-Watson kernel density estimate
#---------------------------------------------------------

ker <- function(x,type){
	if(type=='gaussian'){
		return(dnorm(x))
	}
	if(type=='boxcar'){
		return(0.5*(abs(x)<=1))
	}
	if(type=='epanechnikov'){
		return(0.75*(1-x^2)*(abs(x)<=1))
	}
	if(type=='tricube'){
		return((70*(1-abs(x)^3)^3/81)*(abs(x)<=1))
	}
}



nadarayaWatson <- function(h,plot=F,type){
	# smoothing matrix
	L <- matrix(data=0, nrow = n, ncol = n)
	for(j in 1:n){
		L[j,] <- ker((x-x[j])/h,type=type)
	}
	for(i in 1:n){
		L[i,] <- L[i,]/sum(L[i,])
	}
	rg <- L%*%matrix(y)
	if(plot==TRUE){
		plot(x,y,col='gray40')
		points(x,rg,type='l',col='red',lwd=2)
		legend('topright',paste0('h = ', h))
	}
	return(rg)
}


cvScoreNW <- function(h,type){
	# smoothing matrix
	L <- matrix(data=0, nrow = n, ncol = n)
	for(j in 1:n){
		L[j,] <- ker((x-x[j])/h,type=type)
		L[j,] <- L[j,]/sum(L[j,])
	}
	rg <- L%*%matrix(y)
	return(
		mean(
			( (y-rg)/(1-diag(L)) )^2
		)
	)
}


h <- seq(1,30,length=100)
cvValues <- numeric(100)
j<-0
for(i in h){
	j<-j+1
	cvValues[j] <- cvScoreNW(i,type='gaussian')
}
pdf(file = '../img/loocvNW.pdf', width = 9, height = 6)
plot(h,cvValues, type = 'l', ylab = 'Leave-one-out cross-validation score',xlab='smoothing parameter (h)',pch=16,col='darkorange', lwd = 2)
dev.off()

hCV <- h[which.min(cvValues)]



reg <- regressogram(hCV,plot=T)
pdf(file = '../img/nadarayaWatson_cmb.pdf',width=9,height=6)
	par(mfrow = c(2,2),mar=c(4,4,1,1))
	nadarayaWatson(1,plot=T,type='gaussian')
	nadarayaWatson(6,plot=T,type='gaussian')
	nadarayaWatson(12.5,plot=T,type='gaussian')
	nadarayaWatson(100,plot=T,type='gaussian')
dev.off()



###########me boxcar (local averages estimate)

h <- seq(1,60,length=100)
cvValues <- numeric(100)
j<-0
for(i in h){
	j<-j+1
	cvValues[j] <- cvScoreNW(i,type='boxcar')
}
plot(h,cvValues, type = 'l', ylab = 'Leave-one-out cross-validation score',xlab='smoothing parameter (h)',pch=16,col='darkorange', lwd = 2)

hCV <- h[which.min(cvValues)]



reg <- regressogram(hCV,plot=T)
pdf(file = '../img/nadarayaWatson_boxcar_cmb.pdf',width=9,height=6)
	par(mfrow = c(2,2),mar=c(4,4,1,1))
	nadarayaWatson(1,plot=T,type='boxcar')
	nadarayaWatson(10,plot=T,type='boxcar')
	nadarayaWatson(27,plot=T,type='boxcar')
	nadarayaWatson(100,plot=T,type='boxcar')
dev.off()




#---------------------------------------------------------
# Cubic spline
#---------------------------------------------------------




require(splines)

fit1 <- smooth.spline(x, y, lambda=0.000001) #16 degrees of freedom
fit2 <- smooth.spline(x, y, lambda=0.001) #16 degrees of freedom
fit3 <- smooth.spline(x, y, lambda=1) #16 degrees of freedom
fit4 <- smooth.spline(x, y, lambda=1000) #16 degrees of freedom

pdf(file ='../img/splines_cmb.pdf',width=9,height=6)
par(mfrow = c(2,2), mar=c(4,4,1,1))
plot(x, y, col="grey", xlab="x", ylab="y")
lines(fit1, col = "red", lwd = 2)
legend("topright", as.expression(bquote(h*' = 10'^{-6})))
plot(x, y, col="grey", xlab="x", ylab="y")
lines(fit2, col = "red", lwd = 2)
legend("topright", as.expression(bquote(h*' = 10'^{-3})))
plot(x, y, col="grey", xlab="x", ylab="y")
lines(fit3, col = "red", lwd = 2)
legend("topright", as.expression(bquote(h*' = 1')))
plot(x, y, col="grey", xlab="x", ylab="y")
lines(fit4, col = "red", lwd = 2)
legend("topright", as.expression(bquote(h*' = 10'^{3})))
dev.off()




fit1 <- smooth.spline(x, y, cv = TRUE) #16 degrees of freedom
#Plotting both cubic and Smoothing Splines 
plot(x, y, col="grey", xlab="Age", ylab="Wages")
lines(fit1, col = "red", lwd = 2)


library(RColorBrewer)
myCol <- brewer.pal(6, 'Set2')
#---------------------------------------------------------
# Local polynomial
#---------------------------------------------------------

library("NonpModelCheck")


#---------------------------------------------------------
# Local polynomial
#---------------------------------------------------------



library("NonpModelCheck")
fit1 <- localpoly.reg(x, y, degree.pol = 3, kernel.type = "gaussian", bandwidth = 1)
fit2 <- localpoly.reg(x, y, degree.pol = 3, kernel.type = "gaussian", bandwidth = 15)
fit3 <- localpoly.reg(x, y, degree.pol = 3, kernel.type = "gaussian", bandwidth = 35)
fit4 <- localpoly.reg(x, y, degree.pol = 3, kernel.type = "gaussian", bandwidth = 100)
pdf(file = '../img/localPolynomial_cmb.pdf',width=9,height=6)
par(mfrow = c(2,2), mar=c(4,4,1,1))
plot(x, y, col='gray40')
points(x, fit1$predicted, type = 'l', col = 'red', lwd = 2)
legend('topright', "h = 1")
plot(x, y, col='gray40')
points(x, fit2$predicted, type = 'l', col = 'red', lwd = 2)
legend('topright', "h = 15")
plot(x, y, col='gray40')
points(x, fit3$predicted, type = 'l', col = 'red', lwd = 2)
legend('topright', "h = 35")
plot(x, y, col='gray40')
points(x, fit4$predicted, type = 'l', col = 'red', lwd = 2)
legend('topright', "h = 100")
dev.off()



pdf(file ='../img/cmb_data.pdf',width=9,height=6)
	plot(x, y, col="grey", xlab=bquote(italic(x)),ylab=bquote(italic(y)))
	nw <- nadarayaWatson(12.5,plot = F,type='gaussian')
	reggram <- regressogram(hCV, plot = F)
	lines(fit1, col = myCol[1], lwd = 4, lty = 1)
	points(x, fit2$predicted, type = "l", col = myCol[4], lwd = 4, lty = 4)
	points(x, nw, type = 'l', col = myCol[2], lwd=4, lty = 2)
	points(x, reggram, type = 'l', col = myCol[3], lwd=4, lty = 1)
	legend("topright", c("regressogram",  "Nadaraya-Watson", "local cubic polynomial", "cubic spline"), col = myCol[c(3, 2, 4, 1)], lty = c(1, 2, 4, 1), lwd = 2)
dev.off()


