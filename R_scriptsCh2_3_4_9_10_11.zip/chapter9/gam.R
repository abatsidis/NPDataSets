library(mgcv)
set.seed(1)
n <-200
x <- -10 + 20*runif(n)
y <--10+20*runif(n)
z <- sin(sqrt(x^2+y^2))/sqrt(x^2+y^2) + rnorm(n, sd = 0.1)
b3 <- gam(z ~ s(x) + s(y))
b4 <- gam(z ~ s(x, y))



pdf(file ='../img/gam0.pdf',width=6,height=6)
	par(mar = c(0,0,0,0))
        vis.gam(b3, theta=-45)
dev.off()


pdf(file ='../img/gam.pdf',width=6,height=6)
	par(mar = c(0,0,0,0))
        vis.gam(b4, theta=-45)
dev.off()
pdf(file ='../img/gamScatter.pdf',width=6,height=6)
        pairs(cbind(z, x, y))
dev.off()


library("rpart")
library("rpart.plot")
myTree <- rpart(z ~ x+y)
pdf(file ='../img/tree.pdf',width=9,height=6)
	rpart.plot(myTree, box.palette="RdBu", shadow.col="gray")
dev.off()


