library(RColorBrewer)
myCol <-  brewer.pal(9, "Set1")

#-----------------------------------------------------------------
#	Example (4.6)
#-----------------------------------------------------------------
x <- c(-1.15,-1.05,-0.65,-0.63,-0.60,-0.58,-0.56,-0.31,-0.17,-0.05,-0.01,0.04 ,0.11 ,0.12 ,0.72 ,1.17 ,1.34 ,1.58 ,1.68 ,2.46)
n <- length(x)
#------------------------------------
#	1.1: empirical cdf
#------------------------------------
Fn <- ecdf(x)


#------------------------------------
#	1.2	DKW confidence band
#------------------------------------
dkw <- function(x, a, x_evaluate = x){
        x <- sort(x)
        Fn <- ecdf(x)
        n <- length(x)
        ub <- apply(cbind(1,
                Fn(x_evaluate) + sqrt(log(2/a)/(2*n))), 1, min)
        lb <- apply(cbind(0,
                Fn(x_evaluate) - sqrt(log(2/a)/(2*n)))
                ,1 , max)
        cb <- cbind(lb, ub)
        return(cb)
}

pdf(file = 'example_4.6.pdf', width = 9, height = 7)
par(mar = c(4,3,1,1))
xSeq <- seq(-3,3,length = 1000)
plot(Fn,xlim=c(-3,3),col.hor = myCol[1], lwd = 1.5, ylab = '', main = '')
points(xSeq, pnorm(xSeq),type='l',col=myCol[2],lwd = 1.5)
#	plot L, U bounds
cb <- dkw(x, 0.05, xSeq)
points(xSeq, cb[,1],col = myCol[3], type = 'l', lty=2, lwd = 1.5)
points(xSeq, cb[,2],col = myCol[3], type = 'l', lty=2, lwd = 1.5)

#------------------------------------
#	1.6 KS distance(Fn, Ftrue) 
#------------------------------------
epsilon <- 1e-6
Xpoints <- c(sort(x)) 
myTab <- cbind(
	Xpoints,
	Fn(Xpoints-epsilon) , 
	Fn(Xpoints) ,
	pnorm(Xpoints) , 
	abs(Fn(Xpoints) - pnorm(Xpoints)),
	abs(Fn(Xpoints-epsilon) - pnorm(Xpoints))  )
colnames(myTab) <- c('x', 'Fn_x-', 'Fn_x', 'F0', 'D+', 'D-')
ks <- max(myTab[,5:6])
index_max <- which.max(apply(myTab[,5:6],1,max))

arrows(x0=Xpoints[index_max], 
	y0=Fn(Xpoints[index_max]-epsilon), 
	x1 = Xpoints[index_max], 
	y1 = pnorm(Xpoints[index_max]),
	code=3, angle=10, col = myCol[9],lwd = 1.5)



leg = as.expression(c(bquote(hat(italic(F))[italic(n)]*"("*italic(x)*")"), '95% CB (DKW)', bquote(italic(F)[0]*"("*italic(x)*")"), bquote(italic(D)[italic(n)]*" = "*.(round(ks,5)))))
legend('bottomright', leg, col=myCol[c(1,3,2,9)],lty=c(1,2,1,1),lwd = 1.5)
dev.off()

