
dkw <- function(x, a, x_evaluate = x){
        x <- sort(x)
        Fn <- ecdf(x)
        n <- length(x)
        ub <- apply(cbind(1,
                Fn(x_evaluate) + sqrt(log(2/a)/(2*n))), 1, min)
        lb <- apply(cbind(0,
                Fn(x_evaluate) - sqrt(log(2/a)/(2*n)))
                ,1 , max)
        cb <- cbind(lb, ub)
        return(cb)
}


#	nerve data
x <- as.numeric(
	unlist(
		strsplit(
			#readLines("http://www.stat.cmu.edu/~larry/all-of-nonpar/=data/nerve.dat"), "\\t")
			readLines("https://www.stat.cmu.edu/~larry/all-of-nonpar/=data/nerve.dat"), "\\t")
		)
	)
x <- x[!is.na(x)]



URL <- "https://www.stat.cmu.edu/~larry/all-of-nonpar/=data/nerve.dat"
download.file(URL, destfile = "nerve_data.dat", method="curl")

#####
con <- file("nerve.dat", "r")
x <- as.numeric(
	unlist(
		strsplit(
			readLines(con), "\\t")
		)
	)
	close(con)
x <- x[!is.na(x)]




#pdf(file='../img/nerveHIST.pdf',width=6,height=6)
par(mar = c(4,4,1,1))
hist(x,  main = "", xlab = bquote(italic(x)))
#dev.off()


#pdf(file='../img/nerveECDF.pdf',width=6,height=6)
Fn <- ecdf(x)
xSeq <- seq(0,1.5,length=1000)
par(mar = c(4,4.5,1,1))
plot(Fn, xlim = c(0,1.5), ylab = bquote(F[n](italic(x))), xlab = bquote(italic(x)),
	col.hor = "blue", do.points = FALSE, main = "")
cb <- dkw(x, 0.05, xSeq)
points(xSeq, cb[,1],col = "red", type = "l", lty = 1)
points(xSeq, cb[,2],col = "red", type = "l", lty = 1)
legend('bottomright', c('Empirical CDF', '95% DKW confidence band'), col=c('blue','red'),lty=1)
#dev.off()


xValues <- (1:12)/10
pn <- Fn(xValues)
alpha <- 0.05
dkwV <- dkw(x, alpha, xValues)
n <- length(x)
aciL <- pn - qnorm(alpha/2, lower.tail = FALSE)*sqrt(pn*(1-pn)/n)
aciU <- pn + qnorm(alpha/2, lower.tail = FALSE)*sqrt(pn*(1-pn)/n)
results <- round(cbind(xValues, pn, dkwV, aciL, aciU), 3)
colnames(results) <- c("x", "Fn", "DKW_low", "DKW_up", "Wald_low", "Wald_up")
results

mu = mean(x)
mu
s2 <- var(x)*(n-1)/n
s2 
library('e1071')
kappa = skewness(x, type = 1)
kappa 




#-------------------------------------------------
#       Binomial-based CI
#-------------------------------------------------

alpha <- 0.05
result <- matrix(NA, 3, 4)
colnames(result) <- c("p", "q_p", "95_low", "95_up")
j <- 0
for(p in 3:1/4){
	probTable <- cbind(0:(n+1), pbinom(q = (-1):n, 
		        size = n, prob = 1 - p), c(-Inf, sort(x), Inf))
	bin_lo <- probTable[tail(which(probTable[,2] - alpha/2<=0),1),3]
	bin_up <- probTable[which(probTable[,2] - 1 + alpha/2 >= 0)[1],3]
	j <- j + 1
	result[j, ] <- c(p, quantile(x, probs = 1 - p, type = 1), bin_lo, bin_up)
}
result






