x <- read.table("galaxy.txt")[,1]

dkw <- function(x, a, x_evaluate = x){
        x <- sort(x)
        Fn <- ecdf(x)
        n <- length(x)
        ub <- apply(cbind(1,
                Fn(x_evaluate) + sqrt(log(2/a)/(2*n))), 1, min)
        lb <- apply(cbind(0,
                Fn(x_evaluate) - sqrt(log(2/a)/(2*n)))
                ,1 , max)
        cb <- cbind(lb, ub)
        return(cb)
}


par(mar = c(4,4.5,1,1))
xSeq <- seq(5,40, length = 1000)
plot(Fn,xlim=c(5,40),ylab = bquote(F[n](italic(x))), xlab = bquote(italic(x)) ,col.hor = "blue", do.points = FALSE, main = '')
cb <- dkw(x, 0.05, xSeq)
points(xSeq, cb[,1],col='red',type='l',lty=1)
points(xSeq, cb[,2],col='red',type='l',lty=1)
legend('bottomright', c('Empirical CDF', '95% DKW confidence band'), col=c('blue','red'),lty=1)

