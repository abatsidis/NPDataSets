#       simulated data from normal distribution
#	n = 10
n <- 10
set.seed(2)
x <- round(rnorm(n,0,1),2)

Fn <- ecdf(x)
Fn(-0.5)


pdf(file="../img/ecdf1.pdf",width=9,height=6)
	plot(Fn,xlim=c(-3,3),col.hor = "red", lwd = 2)
dev.off()

pdf(file="../img/ecdf2.pdf",width=9,height=6)
        plot(Fn,xlim=c(-3,3),col.hor = "red", lwd = 2)
        xSeq <- seq(-3,3,length=1000)
        points(xSeq,pnorm(xSeq),type="l",col="blue",lwd=2)
        legend("bottomright", c("estimate", "true"), col=c("red","blue"),lty=1,lwd=2)
dev.off()



dkw <- function(x, a, x_evaluate = x){
	x <- sort(x)
	Fn <- ecdf(x)
	n <- length(x)
        ub <- apply(cbind(1,
                Fn(x_evaluate) + sqrt(log(2/a)/(2*n))), 1, min)
        lb <- apply(cbind(0,
                Fn(x_evaluate) - sqrt(log(2/a)/(2*n)))
                ,1 , max)
        cb <- cbind(lb, ub)
        return(cb)
}


pdf(file="../img/ecdf3.pdf",width=9,height=6)
plot(Fn,xlim=c(-3,3),col.hor = "red", lwd = 2)
points(xSeq,pnorm(xSeq),type="l",col="blue",lwd=2)

cb <- dkw(x, 0.1)
points(sort(x), cb[,1], col=2, lty = 2, pch=16, lwd=2)
points(sort(x), cb[,2],col = 2, lty = 2, pch=16, lwd=2)
cb <- dkw(x, 0.1, xSeq)
points(xSeq, cb[,1], col = 2, type="l", lty = 2, lwd=2)
points(xSeq, cb[,2], col = 2, type = "l", lty = 2, lwd = 2)
legend("bottomright", c("estimate", "90% CB", "true"), 
	col=c("red", "red", "blue"), lty = c(1,2,1), lwd=2)
dev.off()


#-------------------------------------------------
#       Binomial-based CI
#-------------------------------------------------
#alpha <- 0.05
#p <- 0.5
#probTable <- cbind(0:(n+1), pbinom(q = (-1):n, 
#		size = n, prob = p), c(-Inf, sort(x), Inf))
#bin_lo <- probTable[tail(which(probTable[,2] - alpha/2<=0),1),3]
#bin_up <- probTable[which(probTable[,2] - 1 + alpha/2 >= 0)[1],3]
#result <- c(quantile(x, probs = p, type = 1), bin_lo, bin_up)
#names(result) <- c('estimate', '95_low', '95_up')
#result

alpha  <- 0.05
p <- 0.5
probTable  <- cbind (0:(n+1), pbinom(q = (-1):n, size = n, prob = 1 - p), c(-Inf , sort(x), Inf))
bin_lo <- probTable[tail(which(probTable [,2] - alpha/2 <= 0), 1), 3]
bin_up <- probTable[which(probTable [,2] - 1 + alpha/2 >= 0)[1], 3] 
result  <- c(quantile(x, probs = 1 - p, type = 1), bin_lo , bin_up)
names(result) <- c("estimate", "95_low", "95_up")
result


##################################################################
##################################################################
#       simulated data from normal distribution
#	n = 100



n <- 100
set.seed(20)
x1 <- round(rnorm(n,0,1),2)
Fn <- ecdf(x1)
#pdf(file='../tex/image/ecdfn100.pdf',width=9,height=6)
	plot(Fn,xlim=c(-3,3),col.hor = "red", lwd = 2)
#dev.off()

#pdf(file='../tex/image/ecdfn100_2.pdf',width=9,height=6)
	plot(Fn,xlim=c(-3,3),col.hor = "red", lwd = 2)
	points(xSeq,pnorm(xSeq),type='l',col='blue',lwd=2)
	legend('bottomright', c('estimate', 'true'), col=c('red','blue'),lty=1,lwd=2)
#dev.off()



# Computing pointwise ACI for F(1.64)
pn <- Fn(1.64)	# point estimate
alpha <- 0.1
aci <- pn+c(-1,1)*qnorm(alpha/2,lower.tail=FALSE)*sqrt(pn*(1-pn)/n)
aci <- round(aci,3)

